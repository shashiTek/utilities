import React, { useEffect, useRef } from 'react';
import {
  Chart, BarElement, BarController, CategoryScale,
  LinearScale, Tooltip, Legend,
} from 'chart.js';
import styles from './Charts.module.css';

Chart.register(BarElement, BarController, CategoryScale, LinearScale, Tooltip, Legend);

function BarChart({ id, labels, datasets, height = 160, ariaLabel }) {
  const ref = useRef(null);
  const instance = useRef(null);

  useEffect(() => {
    if (!ref.current) return;
    if (instance.current) instance.current.destroy();
    instance.current = new Chart(ref.current, {
      type: 'bar',
      data: { labels, datasets },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { mode: 'index' } },
        scales: {
          x: {
            ticks: { color: '#7d8590', font: { size: 10, family: "'DM Mono', monospace" } },
            grid: { color: 'rgba(255,255,255,0.04)' },
          },
          y: {
            ticks: { color: '#7d8590', font: { size: 10, family: "'DM Mono', monospace" } },
            grid: { color: 'rgba(255,255,255,0.04)' },
          },
        },
      },
    });
    return () => instance.current?.destroy();
  }, [labels, datasets]);

  return (
    <div style={{ position: 'relative', height }}>
      <canvas ref={ref} id={id} role="img" aria-label={ariaLabel} />
    </div>
  );
}

export default function Charts({ birthYearData, metrics }) {
  const byLabels = birthYearData.map(d => d.year?.toString() ?? '');
  const byCounts = birthYearData.map(d => d.count ?? 0);

  const gpLabels  = ['Goalies avg GP', 'Skaters avg GP'];
  const gpValues  = [
    metrics.avgGP && metrics.goalies ? Math.round(metrics.avgGP) : 0,
    metrics.avgGP && metrics.skaters ? Math.round(metrics.avgGP) : 0,
  ];

  return (
    <div className={styles.row}>
      <div className={styles.card}>
        <div className={styles.title}>Players by birth year</div>
        <BarChart
          id="chart-byyear"
          labels={byLabels}
          datasets={[{ label: 'Players', data: byCounts, backgroundColor: '#1f4f8c', borderRadius: 3 }]}
          ariaLabel="Bar chart showing number of players by birth year"
        />
      </div>

      <div className={styles.card}>
        <div className={styles.title}>Roster by position</div>
        <BarChart
          id="chart-pos"
          labels={['Goalies', 'Skaters']}
          datasets={[{
            label: 'Count',
            data: [metrics.goalies ?? 0, metrics.skaters ?? 0],
            backgroundColor: ['#1f4f8c', '#1a4d2a'],
            borderRadius: 3,
          }]}
          ariaLabel="Bar chart comparing goalie vs skater count"
        />
      </div>
    </div>
  );
}
