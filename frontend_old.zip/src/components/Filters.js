import React from 'react';
import styles from './Filters.module.css';

export default function Filters({ filters, values, onChange }) {
  const set = (k) => (e) => onChange({ ...values, [k]: e.target.value, page: 0 });

  // 1. Unique and sorted birth years (Descending: newest years first)
  const uniqueBirthYears = Array.from(new Set(filters.birthYears || []))
    .sort((a, b) => b - a);

  // 2. Unique and sorted seasons (Alphabetical/Chronological)
  const uniqueSeasons = Array.from(new Set(filters.seasons || []))
    .sort((a, b) => String(a).localeCompare(String(b)));

  // 3. Unique and sorted leagues (Alphabetical)
  const uniqueLeagues = Array.from(new Set(filters.leagues || []))
    .sort((a, b) => String(a).localeCompare(String(b)));

  return (
    <div className={styles.bar}>
      <div className={styles.group}>
        <label className={styles.label}>Birth year</label>
        <select className={styles.select} value={values.birthYear} onChange={set('birthYear')}>
          <option value="">All years</option>
          {uniqueBirthYears.map(y => (
            <option key={y} value={y}>{y}</option>
          ))}
        </select>
      </div>

      <div className={styles.group}>
        <label className={styles.label}>Season</label>
        <select className={styles.select} value={values.season} onChange={set('season')}>
          <option value="">All seasons</option>
          {uniqueSeasons.map(s => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
      </div>

      <div className={styles.group}>
        <label className={styles.label}>League</label>
        <select className={styles.select} value={values.league} onChange={set('league')}>
          <option value="">All leagues</option>
          {uniqueLeagues.map(l => (
            <option key={l} value={l}>{l.toUpperCase()}</option>
          ))}
        </select>
      </div>

      <div className={styles.group}>
        <label className={styles.label}>Position</label>
        <select className={styles.select} value={values.position} onChange={set('position')}>
          <option value="">All positions</option>
          <option value="G">Goaltender</option>
          <option value="F">Forward</option>
          <option value="D">Defense</option>
        </select>
      </div>

      <div className={styles.group}>
        <label className={styles.label}>Search</label>
        <input 
          className={styles.input} 
          type="text" 
          placeholder="Name or team…" 
          value={values.search} 
          onChange={set('search')} 
        />
      </div>

      <button 
        className={styles.reset} 
        onClick={() => onChange({ birthYear: '', season: '', league: '', position: '', search: '', page: 0 })}
      >
        Clear
      </button>
    </div>
  );
}
