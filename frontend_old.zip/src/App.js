import React, { useState, useEffect, useCallback } from 'react';
import MetricCards  from './components/MetricCards';
import Filters      from './components/Filters';
import PlayerTable  from './components/PlayerTable';
import Charts       from './components/Charts';
import QueryDisplay from './components/QueryDisplay';
import useDebounce  from './hooks/useDebounce';
import { fetchFilters, fetchMetrics, fetchPlayers, fetchBirthChart } from './api';
import styles from './App.module.css';

const DEFAULT_FILTERS = {
  birthYear: '',
  season:    '',
  league:    '',
  position:  '',
  search:    '',
  page:      0,
  sortBy:    'player_name',
  sortDir:   'asc',
};

export default function App() {
  const [filterOptions, setFilterOptions] = useState({});
  const [filters, setFilters]             = useState(DEFAULT_FILTERS);
  const [players, setPlayers]             = useState({ data: [], total: 0, query: '' });
  const [metrics, setMetrics]             = useState({});
  const [birthData, setBirthData]         = useState([]);
  const [loading, setLoading]             = useState(false);
  const [error, setError]                 = useState(null);

  const debouncedSearch = useDebounce(filters.search, 400);

  // Load static filter options once
  useEffect(() => {
    fetchFilters()
      .then(setFilterOptions)
      .catch(err => console.error('Filter load failed:', err));

    fetchBirthChart()
      .then(setBirthData)
      .catch(err => console.error('Chart load failed:', err));
  }, []);

  // Reload players + metrics whenever filters change
  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    const params = {
      birthYear: filters.birthYear,
      season:    filters.season,
      league:    filters.league,
      position:  filters.position,
      search:    debouncedSearch,
      page:      filters.page,
      pageSize:  50,
      sortBy:    filters.sortBy,
      sortDir:   filters.sortDir,
    };
    try {
      const [p, m] = await Promise.all([
        fetchPlayers(params),
        fetchMetrics(params),
      ]);
      setPlayers(p);
      setMetrics(m);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [filters.birthYear, filters.season, filters.league, filters.position,
      filters.page, filters.sortBy, filters.sortDir, debouncedSearch]);

  useEffect(() => { load(); }, [load]);

  const handleSort = (key) => {
    setFilters(f => ({
      ...f,
      sortBy:  key,
      sortDir: f.sortBy === key && f.sortDir === 'desc' ? 'asc' : 'desc',
      page:    0,
    }));
  };

  return (
    <div className={styles.layout}>
      {/* Sidebar */}
      <aside className={styles.sidebar}>
        <div className={styles.brand}>
          <div className={styles.brandIcon}>EP</div>
          <div>
            <div className={styles.brandName}>Scout DB</div>
            <div className={styles.brandSub}>EliteProspects</div>
          </div>
        </div>

        <nav className={styles.nav}>
          <div className={styles.navItem + ' ' + styles.navActive}>
            <span className={styles.navIcon}>◈</span> Players
          </div>
          <div className={styles.navItem}>
            <span className={styles.navIcon}>◇</span> Teams
          </div>
          <div className={styles.navItem}>
            <span className={styles.navIcon}>◉</span> Leagues
          </div>
        </nav>

        <div className={styles.sideStats}>
          <div className={styles.sideStatItem}>
            <span className={styles.sideStatLabel}>Total players</span>
            <span className={styles.sideStatVal}>{metrics.totalPlayers?.toLocaleString() ?? '—'}</span>
          </div>
          <div className={styles.sideStatItem}>
            <span className={styles.sideStatLabel}>Goalies</span>
            <span className={styles.sideStatVal}>{metrics.goalies ?? '—'}</span>
          </div>
          <div className={styles.sideStatItem}>
            <span className={styles.sideStatLabel}>Skaters</span>
            <span className={styles.sideStatVal}>{metrics.skaters ?? '—'}</span>
          </div>
        </div>

        <div className={styles.pipeline}>
          <div className={styles.pipelineLabel}>Pipeline</div>
          {['organization.py', 'teams.py', 'players.py', 'player_stats.py'].map((s, i) => (
            <div key={s} className={styles.pipelineStep}>
              <span className={styles.pipelineNum}>{i + 1}</span>
              <span className={styles.pipelineName}>{s}</span>
            </div>
          ))}
        </div>
      </aside>

      {/* Main content */}
      <main className={styles.main}>
        <header className={styles.header}>
          <div>
            <h1 className={styles.title}>Player stats</h1>
            <p className={styles.subtitle}>Query by birth year, league, season, and position</p>
          </div>
          {error && <div className={styles.error}>⚠ {error}</div>}
        </header>

        <Filters
          filters={filterOptions}
          values={filters}
          onChange={setFilters}
        />

        <MetricCards metrics={metrics} loading={loading} />

        <Charts birthYearData={birthData} metrics={metrics} />

        <QueryDisplay query={players.query || ''} />

        <PlayerTable
          data={players.data || []}
          total={players.total || 0}
          page={filters.page}
          pageSize={50}
          loading={loading}
          sortBy={filters.sortBy}
          sortDir={filters.sortDir}
          onSort={handleSort}
          onPage={(p) => setFilters(f => ({ ...f, page: p }))}
        />
      </main>
    </div>
  );
}
